#!/bin/bash
lxc stop $1
