#!/bin/bash
lxc start $1
