test('math-test', () => {

});

test('another-test', () => {
    throw new Error('Fail');
});